package application;
	
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import java.sql.*;
import java.sql.Date;
import java.time.*;
import java.util.*;

public class Main extends Application {

    private Connection connection;
    private String dbUrl = "jdbc:postgresql://3e24e-rw.db.pub.dbaas.postgrespro.ru/dbstud";
    private String dbUser = "blinkov_pv";
    private String dbPass = "G#noS%K&7xn#";

    private TableView<Player> tblPlayers;
    private TableView<Team> tblTeams;
    private TableView<TeamRoster> tblRoster;
    private TableView<Tournament> tblTournaments;
    private TableView<Match> tblMatches;
    private TableView<Standing> tblStandings;

    private ComboBox<Integer> cbTeamIdRoster, cbPlayerIdRoster;
    private ComboBox<Integer> cbTourIdReg, cbTeamIdReg;
    private ComboBox<Integer> cbTourIdMatch, cbHomeIdMatch, cbAwayIdMatch;
    private ComboBox<Integer> cbTourIdStandings;
    private ComboBox<Integer> cbTourIdStatus;
    
    // Для отображения состава команды
    private ComboBox<Integer> cbViewTeamRoster;

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Система организации спортивных турниров");
        primaryStage.setWidth(1200);
        primaryStage.setHeight(800);

        HBox topPanel = createTopPanel();
        TabPane tabPane = new TabPane();
        tabPane.getTabs().addAll(createRosterTab(), createParticipantsTab(), createMatchesTab(), createStandingsTab());

        BorderPane root = new BorderPane();
        root.setTop(topPanel);
        root.setCenter(tabPane);

        primaryStage.setScene(new Scene(root));
        primaryStage.show();
        connectAndLoad();
    }

    private HBox createTopPanel() {
        HBox box = new HBox(10);
        box.setPadding(new Insets(10));
        box.setStyle("-fx-background-color: #e8f4f8;");

        ComboBox<String> cbDbType = new ComboBox<>();
        cbDbType.getItems().addAll("PostgreSQL", "Firebird");
        cbDbType.setValue("PostgreSQL");
        
        TextField tfUrl = new TextField(dbUrl); 
        tfUrl.setPrefWidth(350);
        
        TextField tfUser = new TextField(dbUser); 
        tfUser.setPrefWidth(100);
        
        TextField tfPass = new TextField(dbPass); 
        tfPass.setPrefWidth(100); 
        tfPass.setPromptText("Пароль");
        
        // Обработчик выбора СУБД - обновляет URL, логин, пароль
        cbDbType.setOnAction(e -> {
            if ("Firebird".equals(cbDbType.getValue())) {
                tfUrl.setText("jdbc:firebirdsql://localhost:3050/C:/Users/blink/Documents/employee.fdb");
                tfUser.setText("sysdba");
                tfPass.setText("masterkey");
            } else {
                tfUrl.setText("jdbc:postgresql://3e24e-rw.db.pub.dbaas.postgrespro.ru:5432/dbstud");
                tfUser.setText("blinkov_pv");
                tfPass.setText("G#noS%K&7xn#");
            }
        });

        // Кнопка показать/скрыть пароль
        CheckBox cbShowPassword = new CheckBox("Показать");
        cbShowPassword.setOnAction(e -> {
            if (cbShowPassword.isSelected()) {
                tfPass.setText(dbPass);
            } else {
                tfPass.setText("xxxxx");
            }
        });
        
        Button btnConnect = new Button("Подключиться");
        btnConnect.setOnAction(e -> { 
            dbUrl = tfUrl.getText(); 
            dbUser = tfUser.getText(); 
           // dbPass = cbShowPassword.isSelected() ? tfPass.getText() : "G#noS%K&7xn#";
            if (cbShowPassword.isSelected()) {
                dbPass = tfPass.getText(); 
            } else {
                if ("Firebird".equals(cbDbType.getValue())) {
                    dbPass = "masterkey";  
                } else {
                    dbPass = "G#noS%K&7xn#";
                }
            }
            connectAndLoad(); 
        });

        box.getChildren().addAll(
            new Label("СУБД:"), cbDbType, 
            new Label("URL:"), tfUrl, 
            new Label("User:"), tfUser, 
            new Label("Password:"), tfPass, 
            cbShowPassword,
            btnConnect
        );
        return box;
    }

    private void connectAndLoad() {
        try {
            // Сначала закрываем старое соединение
            if (connection != null) {
                try {
                    if (!connection.isClosed()) {
                        connection.close();
                    }
                } catch (SQLException e) {
                    // Игнорируем ошибки закрытия
                }
            }
            connection = null;
            
            // Небольшая пауза для освобождения ресурсов
            Thread.sleep(100);
            
            // Устанавливаем новое соединение
            connection = DriverManager.getConnection(dbUrl, dbUser, dbPass);
            showAlert(Alert.AlertType.INFORMATION, "Успех", "Подключение к " + 
                (dbUrl.contains("firebird") ? "Firebird" : "PostgreSQL") + " установлено.");
            refreshAllData();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            showAlert(Alert.AlertType.ERROR, "Ошибка", "Прерывание потока");
        } catch (SQLException ex) {
            showAlert(Alert.AlertType.ERROR, "Ошибка подключения", 
                "СУБД: " + (dbUrl.contains("firebird") ? "Firebird" : "PostgreSQL") + "\n" + ex.getMessage());
        }
    }

    private Tab createRosterTab() {
        Tab tab = new Tab("Составы (Roster)");
        VBox root = new VBox(10);
        root.setPadding(new Insets(10));

        // Верхняя часть: Игроки и Команды
        HBox topTables = new HBox(10);
        
        tblPlayers = new TableView<>();
        tblPlayers.getColumns().addAll(col("ID", "playerId"), col("ФИО", "fio"), col("Позиция", "playerPosition"), col("Телефон", "phone"));
        tblPlayers.setPrefWidth(500);
        tblPlayers.setPrefHeight(250);
        
        VBox playersBox = new VBox(5);
        playersBox.getChildren().addAll(new Label("Игроки"), tblPlayers);
        
        tblTeams = new TableView<>();
        tblTeams.getColumns().addAll(col("ID", "teamId"), col("Название", "teamName"), col("Тренер", "coach"), col("Год осн.", "foundedYear"));
        tblTeams.setPrefWidth(500);
        tblTeams.setPrefHeight(250);
        
        VBox teamsBox = new VBox(5);
        teamsBox.getChildren().addAll(new Label("Команды"), tblTeams);
        
        topTables.getChildren().addAll(playersBox, teamsBox);

        // Средняя часть: Просмотр состава команды
        HBox viewRosterBox = new HBox(10);
        viewRosterBox.setStyle("-fx-padding: 10; -fx-background-color: #f5f5f5;");
        
        cbViewTeamRoster = new ComboBox<>();
        Button btnViewRoster = new Button("Посмотреть состав выбранной команды");
        btnViewRoster.setOnAction(e -> safeAction(() -> viewTeamRoster(getValue(cbViewTeamRoster))));
        
        viewRosterBox.getChildren().addAll(new Label("Выберите номер команды:"), cbViewTeamRoster, btnViewRoster);
        
        // Таблица состава
        tblRoster = new TableView<>();
        tblRoster.getColumns().addAll(
            col("ID игрока", "playerId"),
            col("ФИО", "playerName"),
            col("Позиция", "position"),
            col("№", "jerseyNumber"),
            col("Дата вступления", "joinedDate")
        );
        tblRoster.setPrefHeight(200);
     // Кнопка исключения из состава
        HBox removeBox = new HBox(10);
        Button btnRemove = new Button("Исключить из состава");
        btnRemove.setOnAction(e -> safeAction(() -> removeFromRoster(
            getValue(cbViewTeamRoster), 
            tblRoster.getSelectionModel().getSelectedItem()
        )));
        removeBox.getChildren().addAll(new Label("Выберите игрока в таблице:"), btnRemove);
        
        // Нижняя часть: Изменение состава + Создание новых записей
        HBox formsBox = new HBox(10);
        
        // Форма добавления в состав
        VBox addRosterForm = new VBox(5);
        addRosterForm.setStyle("-fx-border-color: #ccc; -fx-padding: 10;");
        addRosterForm.getChildren().add(new Label("Изменение состава команды"));
        
        HBox form1 = new HBox(10);
        cbTeamIdRoster = new ComboBox<>(); 
        cbPlayerIdRoster = new ComboBox<>();
        TextField tfJersey = new TextField(); 
        tfJersey.setPromptText("Номер"); 
        tfJersey.setPrefWidth(60);
        DatePicker dpJoined = new DatePicker();
        Button btnAdd = new Button("Добавить в состав");

        btnAdd.setOnAction(e -> safeAction(() -> addToRoster(
            getValue(cbTeamIdRoster), 
            getValue(cbPlayerIdRoster), 
            getInt(tfJersey), 
            dpJoined.getValue()
        )));
        
        form1.getChildren().addAll(
            new Label("Команда:"), cbTeamIdRoster, 
            new Label("Игрок:"), cbPlayerIdRoster, 
            tfJersey, 
            new Label("Дата:"), dpJoined, 
            btnAdd
        );
        addRosterForm.getChildren().add(form1);
        
        // Форма создания нового игрока
        VBox newPlayerForm = new VBox(5);
        newPlayerForm.setStyle("-fx-border-color: #ccc; -fx-padding: 10;");
        newPlayerForm.getChildren().add(new Label("Добавление нового игрока"));
        
        TextField tfFirstName = new TextField(); tfFirstName.setPromptText("Имя");
        TextField tfSecondName = new TextField(); tfSecondName.setPromptText("Отчество");
        TextField tfLastName = new TextField(); tfLastName.setPromptText("Фамилия");
        DatePicker dpBirth = new DatePicker(); dpBirth.setPromptText("Дата рождения");
        TextField tfPosition = new TextField(); tfPosition.setPromptText("Позиция");
        TextField tfPhone = new TextField(); tfPhone.setPromptText("Телефон");
        Button btnCreatePlayer = new Button("Добавить игрока");
        
        btnCreatePlayer.setOnAction(e -> safeAction(() -> createPlayer(
            tfFirstName.getText(), tfSecondName.getText(), tfLastName.getText(),
            dpBirth.getValue(), tfPosition.getText(), tfPhone.getText()
        )));
        
        newPlayerForm.getChildren().addAll(
            tfFirstName, tfSecondName, tfLastName, dpBirth, tfPosition, tfPhone, btnCreatePlayer
        );
        
        // Форма создания новой команды
        VBox newTeamForm = new VBox(5);
        newTeamForm.setStyle("-fx-border-color: #ccc; -fx-padding: 10;");
        newTeamForm.getChildren().add(new Label("Добавить новую команду"));
        
        TextField tfTeamName = new TextField(); tfTeamName.setPromptText("Название");
        TextField tfCoach = new TextField(); tfCoach.setPromptText("Тренер");
        TextField tfFounded = new TextField(); tfFounded.setPromptText("Год");
        Button btnCreateTeam = new Button("Добавить команду");
        
        btnCreateTeam.setOnAction(e -> safeAction(() -> createTeam(
            tfTeamName.getText(), tfCoach.getText(), getInt(tfFounded)
        )));
        
        newTeamForm.getChildren().addAll(tfTeamName, tfCoach, tfFounded, btnCreateTeam);
        
        formsBox.getChildren().addAll(addRosterForm, newPlayerForm, newTeamForm);
        
        root.getChildren().addAll(topTables, viewRosterBox, tblRoster, removeBox, formsBox);
        tab.setContent(root);
        return tab;
    }
    
 // Исключение игрока из состава команды
    private void removeFromRoster(Integer teamId, TeamRoster selectedPlayer) {
        if (teamId == null) throw new IllegalArgumentException("Выберите команду");
        if (selectedPlayer == null) throw new IllegalArgumentException("Выберите игрока в таблице состава");
        
        try {
            connection.setAutoCommit(false);
            
            // Обновляем left_date = текущая дата (мягкое удаление)
            try (PreparedStatement ps = connection.prepareStatement(
                "UPDATE team_roster SET left_date = ? WHERE team_id = ? AND player_id = ? AND left_date IS NULL"
            )) {
                ps.setDate(1, java.sql.Date.valueOf(LocalDate.now()));
                ps.setInt(2, teamId);
                ps.setInt(3, selectedPlayer.getPlayerId());
                int updated = ps.executeUpdate();
                if (updated == 0) throw new SQLException("Запись не найдена или игрок уже исключён");
            }
            
            connection.commit();
            showAlert(Alert.AlertType.INFORMATION, "Успех", 
                "Игрок " + selectedPlayer.getPlayerName() + " исключён из состава команды");
                
        } catch (SQLException e) { 
            try { connection.rollback(); } catch (SQLException ignored) {} 
            throw new RuntimeException(e); 
        }
    }

    //Вкладка с регистрацией на турниры
    private Tab createParticipantsTab() {
        Tab tab = new Tab("Регистрация на турнир");
        VBox root = new VBox(10);
        root.setPadding(new Insets(10));

        tblTournaments = new TableView<>();
        tblTournaments.getColumns().addAll(
            col("ID", "tourId"), 
            col("Название", "tourName"), 
            col("Формат", "format"), 
            col("Статус", "status"), 
            col("Период", "dates")
        );
        tblTournaments.setPrefHeight(200);

        // Форма регистрации команды на турнир
        HBox regForm = new HBox(10);
        regForm.setStyle("-fx-border-color: #4CAF50; -fx-border-width: 1; -fx-padding: 10;");
        regForm.getChildren().add(new Label("📋 Регистрация команды на турнир"));
        regForm.setPrefWidth(Double.MAX_VALUE);
        
        cbTourIdReg = new ComboBox<>(); 
        cbTeamIdReg = new ComboBox<>();
        DatePicker dpReg = new DatePicker();
        Button btnReg = new Button("Зарегистрировать команду");
        btnReg.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");
        
        btnReg.setOnAction(e -> safeAction(() -> registerTeam(
            getValue(cbTourIdReg), 
            getValue(cbTeamIdReg), 
            dpReg.getValue()
        )));

        regForm.getChildren().addAll(
            new Label("Турнир:"), cbTourIdReg, 
            new Label("Команда:"), cbTeamIdReg, 
            new Label("Дата рег.:"), dpReg, 
            btnReg
        );
        
        // Форма создания нового турнира
        HBox createTourForm = new HBox(10);
        createTourForm.setStyle("-fx-border-color: #2196F3; -fx-border-width: 1; -fx-padding: 10;");
        createTourForm.getChildren().add(new Label("🏆 Создание нового турнира"));
        createTourForm.setPrefWidth(Double.MAX_VALUE);
        
        TextField tfTourName = new TextField();
        tfTourName.setPromptText("Название турнира");
        tfTourName.setPrefWidth(200);
        
        ComboBox<String> cbFormat = new ComboBox<>();
        cbFormat.getItems().addAll("League", "Knockout", "Group", "Playoff");
        cbFormat.setValue("League");
        cbFormat.setPromptText("Формат");
        
        DatePicker dpStartDate = new DatePicker();
        dpStartDate.setPromptText("Дата начала");
        
        DatePicker dpEndDate = new DatePicker();
        dpEndDate.setPromptText("Дата окончания");
        
        Button btnCreateTournament = new Button("Создать турнир");
        btnCreateTournament.setStyle("-fx-background-color: #2196F3; -fx-text-fill: white;");
        btnCreateTournament.setOnAction(e -> safeAction(() -> createTournament(
            tfTourName.getText(),
            cbFormat.getValue(),
            dpStartDate.getValue(),
            dpEndDate.getValue()
        )));
        
        createTourForm.getChildren().addAll(
            tfTourName, cbFormat, dpStartDate, dpEndDate, btnCreateTournament
        );
        
        // Форма изменения статуса турнира
        HBox updateStatusForm = new HBox(10);
        updateStatusForm.setStyle("-fx-border-color: #FF9800; -fx-border-width: 1; -fx-padding: 10;");
        updateStatusForm.getChildren().add(new Label("✏️ Изменить статус турнира"));
        updateStatusForm.setPrefWidth(Double.MAX_VALUE);
        
        cbTourIdStatus = new ComboBox<>(); 
        ComboBox<String> cbNewStatus = new ComboBox<>();
        cbNewStatus.getItems().addAll("PLANNED", "ONGOING", "COMPLETED", "CANCELLED");
        cbNewStatus.setPromptText("Новый статус");
        
        Button btnUpdateStatus = new Button("Изменить статус");
        btnUpdateStatus.setStyle("-fx-background-color: #FF9800; -fx-text-fill: white;");
        btnUpdateStatus.setOnAction(e -> safeAction(() -> updateTournamentStatus(
            getValue(cbTourIdStatus),
            cbNewStatus.getValue()
        )));
        
        updateStatusForm.getChildren().addAll(
            new Label("Турнир:"), cbTourIdStatus,
            new Label("Статус:"), cbNewStatus,
            btnUpdateStatus
        );

        root.getChildren().addAll(tblTournaments, regForm, createTourForm, updateStatusForm);
        tab.setContent(root);
        return tab;
    }

    //Вкладка с турнирами
    private Tab createMatchesTab() {
        Tab tab = new Tab("Матчи");
        VBox root = new VBox(10);
        root.setPadding(new Insets(10));

        tblMatches = new TableView<>();
        tblMatches.getColumns().addAll(col("ID", "matchId"), col("Турнир", "tourName"), col("Матч", "matchup"), col("Дата", "matchDate"), col("Счёт", "score"), col("Статус", "status"));
        tblMatches.setPrefHeight(200);

        HBox createForm = new HBox(10);
        cbTourIdMatch = new ComboBox<>(); cbHomeIdMatch = new ComboBox<>(); cbAwayIdMatch = new ComboBox<>();
        DatePicker dpMatch = new DatePicker();
        TextField tfTime = new TextField("18:00"); tfTime.setPrefWidth(60);
        Button btnCreate = new Button("Создать матч");
        btnCreate.setOnAction(e -> safeAction(() -> scheduleMatch(getValue(cbTourIdMatch), getValue(cbHomeIdMatch), getValue(cbAwayIdMatch), LocalDateTime.of(dpMatch.getValue(), LocalTime.parse(tfTime.getText())), "SCHEDULED")));

        HBox updateForm = new HBox(10);
        TextField tfMatchId = new TextField(); tfMatchId.setPromptText("ID матча"); tfMatchId.setPrefWidth(60);
        ComboBox<String> cbStatus = new ComboBox<>();
        cbStatus.getItems().addAll("SCHEDULED", "IN PROGRESS", "FINISHED", "POSTPONED", "CANCELLED");
        TextField tfHomeSc = new TextField(); tfHomeSc.setPrefWidth(50); tfHomeSc.setPromptText("Счёт Х");
        TextField tfAwaySc = new TextField(); tfAwaySc.setPrefWidth(50); tfAwaySc.setPromptText("Счёт Г");
        Button btnUpdate = new Button("Обновить");
        btnUpdate.setOnAction(e -> safeAction(() -> {
            Integer id = getInt(tfMatchId);
            
            //Получаем значения и сразу убираем пробелы
            String homeText = tfHomeSc.getText().trim();
            String awayText = tfAwaySc.getText().trim();
            String newStatus = cbStatus.getValue();
            
            boolean scoreChanged = !homeText.isEmpty() && !awayText.isEmpty();
            boolean statusChanged = newStatus != null && !newStatus.isEmpty();
            
            if (!scoreChanged && !statusChanged) {
                throw new IllegalArgumentException("Укажите новый статус или введите счёт");
            }
            
            // Сначала обновляем счёт (если нужно)
            if (scoreChanged) {
                updateScore(id, Integer.parseInt(homeText), Integer.parseInt(awayText));
            }
            // Затем обновляем статус (если нужно)
            if (statusChanged) {
                updateStatus(id, newStatus);
            }
            
            
        }));

        createForm.getChildren().addAll(new Label("Номер турнира:"), cbTourIdMatch, new Label("Хозяин:"), cbHomeIdMatch, new Label("Гости:"), cbAwayIdMatch, new Label("Дата:"), dpMatch, new Label("Время:"), tfTime, btnCreate);
        updateForm.getChildren().addAll(new Label("ID:"), tfMatchId, new Label("Статус:"), cbStatus, tfHomeSc, tfAwaySc, btnUpdate);
        root.getChildren().addAll(tblMatches, createForm, updateForm);
        tab.setContent(root);
        return tab;
    }
    
 // Проверка что обе команды зарегистрированы на турнир
    private void validateTeamsRegistered(Integer tourId, Integer homeTeam, Integer awayTeam) throws SQLException {
        String sql = "SELECT COUNT(*) FROM tournament_participants " +
                     "WHERE tournament_id = ? AND team_id IN (?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, tourId);
            ps.setInt(2, homeTeam);
            ps.setInt(3, awayTeam);
            ResultSet rs = ps.executeQuery();
            if (rs.next() && rs.getInt(1) != 2) {
                throw new SQLException("Обе команды должны быть зарегистрированы на этом турнире!");
            }
        }
    }

    //Вкладка с турнирной таблицей
    private Tab createStandingsTab() {
        Tab tab = new Tab("Турнирная таблица");
        VBox root = new VBox(10);
        root.setPadding(new Insets(10));

        tblStandings = new TableView<>();
        tblStandings.getColumns().addAll(col("Команда", "teamName"), col("Количество игр", "played"), col("Побед", "wins"), col("Ничьих", "draws"), col("Поражений", "losses"), col("Забито", "gf"), col("Пропущено", "ga"), col("+/-", "gd"), col("Очки", "points"));
        tblStandings.setPrefHeight(300);

        HBox form = new HBox(10);
        cbTourIdStandings = new ComboBox<>();
        Button btnLoad = new Button("Показать таблицу турнира");
        btnLoad.setOnAction(e -> safeAction(() -> loadStandings(getValue(cbTourIdStandings))));
        form.getChildren().addAll(new Label("Турнир:"), cbTourIdStandings, btnLoad);
        root.getChildren().addAll(tblStandings, form);
        tab.setContent(root);
        return tab;
    }

    // Вспомогательные функции
    private <T> TableColumn<T, Object> col(String title, String prop) {
        TableColumn<T, Object> c = new TableColumn<>(title);
        c.setCellValueFactory(new PropertyValueFactory<>(prop));
        c.setPrefWidth(title.equals("Матч") ? 250 : 90);
        return c;
    }

    private Integer getValue(ComboBox<Integer> cb) {
        Integer v = cb.getValue();
        if (v == null) throw new IllegalArgumentException("Выберите значение из списка");
        return v;
    }

    private Integer getInt(TextField tf) {
        try { return Integer.parseInt(tf.getText()); }
        catch (NumberFormatException e) { throw new IllegalArgumentException("Введите число"); }
    }

    private void safeAction(Runnable action) {
        try { action.run(); refreshAllData(); }
        catch (Exception ex) { 
            String msg = ex.getCause() instanceof SQLException ? ex.getCause().getMessage() : ex.getMessage();
            showAlert(Alert.AlertType.ERROR, "Ошибка операции", msg); 
        }
    }

    private void refreshAllData() {
        if (connection == null) return;
        
        loadTable(tblPlayers, 
            "SELECT player_id AS playerId, " +
            "first_name || ' ' || last_name AS fio, " +
            "POSITIONN AS player_position, " +
            "phone " +
            "FROM players ORDER BY player_id", 
            t -> { try { return new Player(t); } catch (SQLException e) { e.printStackTrace(); return null; } }
        );
        
        // Команды
        loadTable(tblTeams, 
            "SELECT team_id AS teamId, team_name AS teamName, coach, founded_year AS foundedYear " +
            "FROM teams ORDER BY team_id", 
            t -> { try { return new Team(t); } catch (SQLException e) { e.printStackTrace(); return null; } }
        );
        
        // Турниры: конкатенация дат через || (работает в обеих СУБД)
        loadTable(tblTournaments, 
            "SELECT tournament_id AS tourId, tournament_name AS tourName, format, status, " +
            "start_date || ' - ' || end_date AS dates " +
            "FROM tournaments ORDER BY tournament_id", 
            t -> { try { return new Tournament(t); } catch (SQLException e) { e.printStackTrace(); return null; } }
        );
        
        // Матчи: универсальный CASE для отображения счёта
        loadTable(tblMatches, 
            "SELECT m.match_id AS matchId, t.tournament_name AS tourName, " +
            "th.team_name || ' vs ' || ta.team_name AS matchup, " +
            "m.match_date AS matchDate, " +
            "CASE WHEN m.home_score IS NULL OR m.away_score IS NULL THEN '-' " +
            "ELSE CAST(m.home_score AS VARCHAR(10)) || ':' || CAST(m.away_score AS VARCHAR(10)) END AS score, " +
            "m.status " +
            "FROM matches m " +
            "JOIN tournaments t ON m.tournament_id = t.tournament_id " +
            "JOIN teams th ON m.home_team_id = th.team_id " +
            "JOIN teams ta ON m.away_team_id = ta.team_id " +
            "ORDER BY m.match_date", 
            t -> { try { return new Match(t); } catch (SQLException e) { e.printStackTrace(); return null; } }
        );
        
        populateComboBoxes();
    }

    private <T> void loadTable(TableView<T> table, String sql, java.util.function.Function<ResultSet, T> mapper) {
        try (Statement st = connection.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            ObservableList<T> list = FXCollections.observableArrayList();
            while (rs.next()) list.add(mapper.apply(rs));
            table.setItems(list);
        } catch (SQLException e) { throw new RuntimeException(e); }
    }

    private void populateComboBoxes() {
        if (connection == null) return;
        
        try (Statement st = connection.createStatement()) {
            fillBox(st, "SELECT team_id FROM teams ORDER BY team_id", 
                cbTeamIdRoster, cbTeamIdReg, cbHomeIdMatch, cbAwayIdMatch, cbViewTeamRoster);
            fillBox(st, "SELECT player_id FROM players ORDER BY player_id", cbPlayerIdRoster);
            fillBox(st, "SELECT tournament_id FROM tournaments ORDER BY tournament_id", 
                cbTourIdReg, cbTourIdMatch, cbTourIdStandings, cbTourIdStatus); // <-- Добавьте cbTourIdStatus сюда
        } catch (SQLException e) {}
    }

    private void fillBox(Statement st, String sql, ComboBox<Integer>... boxes) throws SQLException {
        ObservableList<Integer> items = FXCollections.observableArrayList();
        try (ResultSet rs = st.executeQuery(sql)) { while (rs.next()) items.add(rs.getInt(1)); }
        for (ComboBox<Integer> box : boxes) box.setItems(items);
    }
    
    // Просмотр состава команды
    private void viewTeamRoster(Integer teamId) {
        String sql = "SELECT p.player_id AS playerId, p.first_name || ' ' || p.last_name AS playerName, " +
                     "p.POSITIONN AS position, " + 
                     "tr.jersey_number AS jerseyNumber, tr.joined_date AS joinedDate " +
                     "FROM team_roster tr " +
                     "JOIN players p ON tr.player_id = p.player_id " +
                     "WHERE tr.team_id = ? AND tr.left_date IS NULL " +
                     "ORDER BY tr.jersey_number";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, teamId);
            ResultSet rs = ps.executeQuery();
            ObservableList<TeamRoster> list = FXCollections.observableArrayList();
            while (rs.next()) list.add(new TeamRoster(rs));
            tblRoster.setItems(list);
        } catch (SQLException e) { throw new RuntimeException(e); }
    }

    private void showAlert(Alert.AlertType type, String title, String msg) {
        new Alert(type, msg, ButtonType.OK).showAndWait();
    }

    // Проверки
    private void validateRule1(int teamId, LocalDate joined) throws SQLException {
        try (PreparedStatement ps = connection.prepareStatement("SELECT founded_year FROM teams WHERE team_id=?")) {
            ps.setInt(1, teamId);
            ResultSet rs = ps.executeQuery();
            if (!rs.next()) throw new SQLException("Команда не найдена");
            if (joined.getYear() < rs.getInt("founded_year")) throw new SQLException("Ошибка. Игрок не может вступить раньше года основания команды (" + rs.getInt("founded_year") + ")");
        }
    }

    private void validateRule2(int playerId, LocalDate joined) throws SQLException {
        try (PreparedStatement ps = connection.prepareStatement("SELECT birth_date FROM players WHERE player_id=?")) {
            ps.setInt(1, playerId);
            ResultSet rs = ps.executeQuery();
            if (!rs.next()) throw new SQLException("Игрок не найден");
            if (Period.between(rs.getDate("birth_date").toLocalDate(), joined).getYears() < 14) throw new SQLException("Ошибка. Игрок должен быть старше 14 лет на момент вступления");
        }
    }
    
    //Игрок не может быть в двух командах одновременно
    private void validatePlayerNotInAnotherTeam(int playerId, Integer currentTeamId) throws SQLException {
        String sql = "SELECT team_id FROM team_roster WHERE player_id = ? AND left_date IS NULL";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, playerId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                int existingTeamId = rs.getInt("team_id");
                if (currentTeamId == null || existingTeamId != currentTeamId) {
                    throw new SQLException("Ошибка. Игрок уже состоит в команде ID=" + existingTeamId + ". Сначала исключите его из текущей команды.");
                }
            }
        }
    }

    private void addToRoster(Integer teamId, Integer playerId, Integer jersey, LocalDate joined) {
        if (teamId == null || playerId == null || jersey == null || joined == null) 
            throw new IllegalArgumentException("Заполните все поля");
        
        try {
            validateRule1(teamId, joined);
            validateRule2(playerId, joined);
            
            connection.setAutoCommit(false);
            
            // Проверяем, есть ли уже запись об этом игроке в team_roster
            String checkSql = "SELECT team_id, left_date FROM team_roster WHERE player_id = ? AND team_id != ?";
            try (PreparedStatement checkPs = connection.prepareStatement(checkSql)) {
                checkPs.setInt(1, playerId);
                checkPs.setInt(2, teamId);
                ResultSet rs = checkPs.executeQuery();
                
                if (rs.next()) {
                    int otherTeamId = rs.getInt("team_id");
                    Date leftDate = rs.getDate("left_date");
                    
                    // Если игрок сейчас в другой команде (left_date IS NULL)
                    if (leftDate == null) {
                        throw new SQLException("Ошибка. Игрок уже состоит в команде ID=" + otherTeamId + 
                                             ". Сначала исключите его из текущей команды.");
                    }
                    // Если игрок был в другой команде, но ушел (left_date IS NOT NULL)
                    // Обновляем existing запись: сбрасываем left_date и обновляем joined_date
                    String updateSql = "UPDATE team_roster SET team_id = ?, jersey_number = ?, " +
                                      "joined_date = ?, left_date = NULL " +
                                      "WHERE player_id = ? AND left_date IS NOT NULL";
                    try (PreparedStatement updatePs = connection.prepareStatement(updateSql)) {
                        updatePs.setInt(1, teamId);
                        updatePs.setInt(2, jersey);
                        updatePs.setDate(3, java.sql.Date.valueOf(joined));
                        updatePs.setInt(4, playerId);
                        updatePs.executeUpdate();
                    }
                } else {
                    // Игрок никогда не был в team_roster - делаем INSERT
                    String insertSql = "INSERT INTO team_roster(team_id, player_id, jersey_number, joined_date) VALUES(?,?,?,?)";
                    try (PreparedStatement insertPs = connection.prepareStatement(insertSql)) {
                        insertPs.setInt(1, teamId);
                        insertPs.setInt(2, playerId);
                        insertPs.setInt(3, jersey);
                        insertPs.setDate(4, java.sql.Date.valueOf(joined));
                        insertPs.executeUpdate();
                    }
                }
            }
            
            connection.commit();
        } catch (SQLException e) { 
            try { connection.rollback(); } catch (SQLException ignored) {} 
            throw new RuntimeException(e); 
        }
    }
    
    // Создание нового игрока
    private void createPlayer(String firstName, String secondName, String lastName, LocalDate birthDate, String position, String phone) {
        if (firstName == null || firstName.isEmpty() || lastName == null || lastName.isEmpty() || birthDate == null) {
            throw new IllegalArgumentException("Заполните обязательные поля (Имя, Фамилия, Дата рождения)");
        }
        try {
            connection.setAutoCommit(false);
            try (PreparedStatement ps = connection.prepareStatement(
                "INSERT INTO players(first_name, second_name, last_name, birth_date, POSITIONN, phone) VALUES(?,?,?,?,?,?)"
            )) {
                ps.setString(1, firstName);
                ps.setString(2, secondName);
                ps.setString(3, lastName);
                ps.setDate(4, java.sql.Date.valueOf(birthDate));
                ps.setString(5, position);
                ps.setString(6, phone);
                ps.executeUpdate();
                connection.commit();
            }
            showAlert(Alert.AlertType.INFORMATION, "Успех", "Игрок успешно создан!");
        } catch (SQLException e) { 
            try { connection.rollback(); } catch (SQLException ignored) {} 
            throw new RuntimeException(e); 
        }
    }
    
    // Создание новой команды
    private void createTeam(String teamName, String coach, Integer foundedYear) {
        if (teamName == null || teamName.isEmpty() || foundedYear == null) {
            throw new IllegalArgumentException("Заполните обязательные поля (Название, Год основания)");
        }
        try {
            connection.setAutoCommit(false);
            try (PreparedStatement ps = connection.prepareStatement(
                "INSERT INTO teams(team_name, coach, founded_year) VALUES(?,?,?)"
            )) {
                ps.setString(1, teamName);
                ps.setString(2, coach);
                ps.setInt(3, foundedYear);
                ps.executeUpdate();
                connection.commit();
            }
            showAlert(Alert.AlertType.INFORMATION, "Успех", "Команда успешно создана!");
        } catch (SQLException e) { 
            try { connection.rollback(); } catch (SQLException ignored) {} 
            throw new RuntimeException(e); 
        }
    }

    private void validateRule5(int tourId, LocalDate regDate) throws SQLException {
        try (PreparedStatement ps = connection.prepareStatement("SELECT start_date FROM tournaments WHERE tournament_id=?")) {
            ps.setInt(1, tourId);
            ResultSet rs = ps.executeQuery();
            if (!rs.next()) throw new SQLException("Турнир не найден");
            if (!regDate.isBefore(rs.getDate("start_date").toLocalDate())) throw new SQLException("Ошибка. Регистрация должна быть завершена до начала турнира");
        }
    }

    private void registerTeam(Integer tourId, Integer teamId, LocalDate regDate) {
        if (tourId == null || teamId == null || regDate == null) 
            throw new IllegalArgumentException("Заполните все поля");
        
        try {
            // Проверяем статус турнира - можно регистрировать только на PLANNED
            String checkSql = "SELECT status, start_date FROM tournaments WHERE tournament_id = ?";
            try (PreparedStatement checkPs = connection.prepareStatement(checkSql)) {
                checkPs.setInt(1, tourId);
                ResultSet rs = checkPs.executeQuery();
                if (!rs.next()) {
                    throw new SQLException("Турнир не найден");
                }
                String status = rs.getString("status");
                LocalDate startDate = rs.getDate("start_date").toLocalDate();
                
                if (!"PLANNED".equals(status)) {
                    throw new SQLException("Ошибка. Можно регистрировать команды только на турниры со статусом PLANNED. " +
                                         "Текущий статус: " + status);
                }
                
                if (!regDate.isBefore(startDate)) {
                    throw new SQLException("Ошибка. Регистрация должна быть завершена до начала турнира");
                }
            }
            
            connection.setAutoCommit(false);
            try (PreparedStatement ps = connection.prepareStatement(
                "INSERT INTO tournament_participants(tournament_id, team_id, reg_date) VALUES(?,?,?)"
            )) {
                ps.setInt(1, tourId); 
                ps.setInt(2, teamId);
                ps.setTimestamp(3, java.sql.Timestamp.valueOf(regDate.atStartOfDay()));
                ps.executeUpdate();
                connection.commit();
            }
            showAlert(Alert.AlertType.INFORMATION, "Успех", "Команда успешно зарегистрирована на турнир!");
        } catch (SQLException e) { 
            try { connection.rollback(); } catch (SQLException ignored) {} 
            throw new RuntimeException(e); 
        }
    }

    private void validateRule3(LocalDateTime matchDate) throws SQLException {
        Timestamp start = Timestamp.valueOf(matchDate.minusHours(2).minusMinutes(30));
        Timestamp end = Timestamp.valueOf(matchDate.plusHours(2).plusMinutes(30));
        try (PreparedStatement ps = connection.prepareStatement("SELECT COUNT(*) FROM matches WHERE match_date BETWEEN ? AND ?")) {
            ps.setTimestamp(1, start); ps.setTimestamp(2, end);
            ResultSet rs = ps.executeQuery();
            if (rs.next() && rs.getInt(1) > 0) throw new SQLException("Ошибка: Стадион занят в это время (±2.5ч)");
        }
    }

    private void validateRule4(int tourId, LocalDateTime matchDate) throws SQLException {
        try (PreparedStatement ps = connection.prepareStatement("SELECT start_date, end_date FROM tournaments WHERE tournament_id=?")) {
            ps.setInt(1, tourId);
            ResultSet rs = ps.executeQuery();
            if (!rs.next()) throw new SQLException("Турнир не найден");
            LocalDate m = matchDate.toLocalDate();
            if (m.isBefore(rs.getDate("start_date").toLocalDate()) || m.isAfter(rs.getDate("end_date").toLocalDate())) throw new SQLException("Ошибка. Дата матча вне периода турнира");
        }
    }

    private void scheduleMatch(Integer tourId, Integer home, Integer away, LocalDateTime matchDate, String status) {
        if (tourId == null || home == null || away == null || matchDate == null) throw new IllegalArgumentException("Заполните все поля");
        if (home.equals(away)) throw new IllegalArgumentException("Команды должны быть разными");
        
        try {
			validateTeamsRegistered(tourId, home, away);
		} catch (SQLException e) {
			e.printStackTrace();
		}
        try (PreparedStatement ps = connection.prepareStatement(
                "SELECT status FROM tournaments WHERE tournament_id = ?"
            )) {
                ps.setInt(1, tourId);
                ResultSet rs = ps.executeQuery();
                if (!rs.next()) throw new SQLException("Турнир не найден");
                String tourStatus = rs.getString("status");
                if (!"PLANNED".equals(tourStatus) && !"ONGOING".equals(tourStatus)) {
                    throw new SQLException("Ошибка. Можно создавать матчи только в турнирах со статусом PLANNED или ONGOING. " +
                                         "Текущий статус: " + tourStatus);
                }
            } catch (SQLException e) { throw new RuntimeException(e); }
        
        try {
            validateRule3(matchDate);
            validateRule4(tourId, matchDate);
            if (matchDate.isBefore(LocalDateTime.now())) throw new SQLException("Ошибка. Нельзя запланировать матч на прошедшее время");
            connection.setAutoCommit(false);
            try (PreparedStatement ps = connection.prepareStatement("INSERT INTO matches(tournament_id, home_team_id, away_team_id, match_date, status) VALUES(?,?,?,?,?)")) {
                ps.setInt(1, tourId); ps.setInt(2, home); ps.setInt(3, away);
                ps.setTimestamp(4, Timestamp.valueOf(matchDate)); ps.setString(5, status);
                ps.executeUpdate();
                connection.commit();
            }
        } catch (SQLException e) { try { connection.rollback(); } catch (SQLException ignored) {} throw new RuntimeException(e); }
    }
 // Проверка что только один матч может быть IN PROGRESS
    private void validateOnlyOneMatchInProgress(Integer matchId, String newStatus) throws SQLException {
        if ("IN PROGRESS".equals(newStatus)) {
            String sql = "SELECT COUNT(*) FROM matches WHERE status = 'IN PROGRESS' AND match_id != ?";
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setInt(1, matchId);
                ResultSet rs = ps.executeQuery();
                if (rs.next() && rs.getInt(1) > 0) {
                    throw new SQLException("Ошибка. Одновременно может идти только один матч (статус IN PROGRESS)!");
                }
            }
        }
    }

    private void validateStatusRules(int matchId, String newStatus) throws SQLException {
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime matchDt;
        String currentStatus;
        
        // Получаем текущие данные матча
        try (PreparedStatement ps = connection.prepareStatement(
            "SELECT match_date, status FROM matches WHERE match_id = ?"
        )) {
            ps.setInt(1, matchId);
            ResultSet rs = ps.executeQuery();
            if (!rs.next()) throw new SQLException("Матч не найден");
            matchDt = rs.getTimestamp("match_date").toLocalDateTime();
            currentStatus = rs.getString("status");
        }
        
        validateOnlyOneMatchInProgress(matchId, newStatus);
        
        // Нельзя поставить SCHEDULED, если время матча прошло
        if ("SCHEDULED".equals(newStatus) && matchDt.isBefore(now)) {
            throw new SQLException("Ошибка. Нельзя установить статус SCHEDULED, если время матча уже прошло");
        }
        
        // Нельзя поставить IN PROGRESS, если разница > 2 часов
        if ("IN PROGRESS".equals(newStatus)) {
            long hoursDiff = Math.abs(Duration.between(matchDt, now).toHours());
            if (hoursDiff > 2) {
                throw new SQLException("Ошибка. Матч можно начать только в окне ±2 часа от назначенного времени");
            }
        }
        
        if ("FINISHED".equals(newStatus) && !"IN PROGRESS".equals(currentStatus)) {
            throw new SQLException("Ошибка. Завершить можно только матч, который сейчас идёт (статус IN PROGRESS)");
        }
        
        // Блокируем изменение статусов у завершённых/отменённых матчей
        if (("FINISHED".equals(currentStatus) || "CANCELLED".equals(currentStatus)) && 
            !"FINISHED".equals(newStatus) && !"CANCELLED".equals(newStatus)) {
            throw new SQLException("Ошибка. Нельзя изменить статус матча со статусом " + currentStatus);
        }
    }

    private void updateStatus(Integer matchId, String status) {
        if (matchId == null) throw new IllegalArgumentException("Введите ID матча");
        try {
            validateStatusRules(matchId, status);
            connection.setAutoCommit(false);
            try (PreparedStatement ps = connection.prepareStatement("UPDATE matches SET status=? WHERE match_id=?")) {
                ps.setString(1, status); ps.setInt(2, matchId);
                if (ps.executeUpdate() == 0) throw new SQLException("Матч №" + matchId + " не найден или статус не изменился");
                connection.commit();
                showAlert(Alert.AlertType.INFORMATION, "Успех", "Статус матча обновлён на: " + status);
            }
        } catch (SQLException e) { try { connection.rollback(); } catch (SQLException ignored) {} throw new RuntimeException(e); }
    }

    private void validateScoreRule(int matchId) throws SQLException {
        try (PreparedStatement ps = connection.prepareStatement("SELECT status FROM matches WHERE match_id=?")) {
            ps.setInt(1, matchId);
            ResultSet rs = ps.executeQuery();
            if (!rs.next()) throw new SQLException("Матч не найден");
            if (!"IN PROGRESS".equals(rs.getString("status"))) throw new SQLException("Ошибка. Изменять счёт можно только при статусе IN PROGRESS");
        }
    }

    private void updateScore(Integer matchId, Integer home, Integer away) {
        if (matchId == null || home == null || away == null) throw new IllegalArgumentException("Заполните ID и счёт");
        try {
            validateScoreRule(matchId);
            connection.setAutoCommit(false);
            try (PreparedStatement ps = connection.prepareStatement("UPDATE matches SET home_score=?, away_score=? WHERE match_id=?")) {
                ps.setInt(1, home); ps.setInt(2, away); ps.setInt(3, matchId);
                ps.executeUpdate();
                connection.commit();
            }
        } catch (SQLException e) { try { connection.rollback(); } catch (SQLException ignored) {} throw new RuntimeException(e); }
    }

    private void loadStandings(Integer tourId) {
        if (tourId == null) throw new IllegalArgumentException("Выберите турнир");
        String sql = "SELECT t.team_name, " +
                "COUNT(m.team_id) AS played, " +
                "SUM(CASE WHEN m.pts=3 THEN 1 ELSE 0 END) AS wins, " +
                "SUM(CASE WHEN m.pts=1 THEN 1 ELSE 0 END) AS draws, " +
                "SUM(CASE WHEN m.pts=0 THEN 1 ELSE 0 END) AS losses, " +
                "COALESCE(SUM(m.goals_for), 0) AS gf, " +
                "COALESCE(SUM(m.goals_against), 0) AS ga, " +
                "COALESCE(SUM(m.goals_for - m.goals_against), 0) AS gd, " +
                "COALESCE(SUM(m.pts), 0) AS points " +
                "FROM ( " +
                "  SELECT home_team_id AS team_id, home_score AS goals_for, away_score AS goals_against, " +
                "    CASE WHEN home_score>away_score THEN 3 WHEN home_score=away_score THEN 1 ELSE 0 END AS pts " +
                "  FROM matches WHERE tournament_id=? AND status='FINISHED' " +
                "  UNION ALL " +
                "  SELECT away_team_id AS team_id, away_score AS goals_for, home_score AS goals_against, " +
                "    CASE WHEN away_score>home_score THEN 3 WHEN away_score=home_score THEN 1 ELSE 0 END AS pts " +
                "  FROM matches WHERE tournament_id=? AND status='FINISHED' " +
                ") m JOIN teams t ON m.team_id=t.team_id " +
                "GROUP BY t.team_name, t.team_id ORDER BY points DESC, gd DESC, t.team_name ASC";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, tourId);
            ps.setInt(2, tourId);
            ResultSet rs = ps.executeQuery();
            ObservableList<Standing> list = FXCollections.observableArrayList();
            while (rs.next()) {
                list.add(new Standing(rs));
            }
            tblStandings.setItems(list);
        } catch (SQLException e) {
            System.err.println("SQL Error: " + e.getMessage());
            System.err.println("SQL State: " + e.getSQLState());
            System.err.println("Error Code: " + e.getErrorCode());
            throw new RuntimeException("Ошибка загрузки турнирной таблицы: " + e.getMessage(), e);
        }
        
    }

 // Изменение статуса турнира
    private void updateTournamentStatus(Integer tourId, String newStatus) {
        if (tourId == null || newStatus == null) {
            throw new IllegalArgumentException("Выберите турнир и новый статус");
        }
        
        try {
            // Проверяем текущий статус
            String checkSql = "SELECT status FROM tournaments WHERE tournament_id = ?";
            try (PreparedStatement checkPs = connection.prepareStatement(checkSql)) {
                checkPs.setInt(1, tourId);
                ResultSet rs = checkPs.executeQuery();
                if (!rs.next()) {
                    throw new SQLException("Турнир не найден");
                }
                String currentStatus = rs.getString("status");
                
                // Можно менять статус только у PLANNED и ONGOING
                if ("COMPLETED".equals(currentStatus) || "CANCELLED".equals(currentStatus)) {
                    throw new SQLException("Ошибка. Нельзя изменить статус турнира со статусом " + 
                                         currentStatus + ". Изменять можно только PLANNED или ONGOING.");
                }
            }
            
            connection.setAutoCommit(false);
            try (PreparedStatement ps = connection.prepareStatement(
                "UPDATE tournaments SET status = ? WHERE tournament_id = ?"
            )) {
                ps.setString(1, newStatus);
                ps.setInt(2, tourId);
                int updated = ps.executeUpdate();
                if (updated == 0) throw new SQLException("Турнир не найден");
                connection.commit();
            }
            showAlert(Alert.AlertType.INFORMATION, "Успех", "Статус турнира успешно изменен на " + newStatus);
        } catch (SQLException e) { 
            try { connection.rollback(); } catch (SQLException ignored) {} 
            throw new RuntimeException(e); 
        }
    }
 // Создание нового турнира
    private void createTournament(String name, String format, LocalDate startDate, LocalDate endDate) {
        if (name == null || name.isEmpty() || format == null || startDate == null || endDate == null) {
            throw new IllegalArgumentException("Заполните все поля (Название, Формат, Даты)");
        }
        
        if (endDate.isBefore(startDate)) {
            throw new IllegalArgumentException("Ошибка. Дата окончания не может быть раньше даты начала!");
        }
        
        try {
            connection.setAutoCommit(false);
            try (PreparedStatement ps = connection.prepareStatement(
                "INSERT INTO tournaments(tournament_name, start_date, end_date, format, status) VALUES(?,?,?,?,?)"
            )) {
                ps.setString(1, name);
                ps.setDate(2, java.sql.Date.valueOf(startDate));
                ps.setDate(3, java.sql.Date.valueOf(endDate));
                ps.setString(4, format);
                ps.setString(5, "PLANNED"); // По умолчанию статус PLANNED
                ps.executeUpdate();
                connection.commit();
            }
            showAlert(Alert.AlertType.INFORMATION, "Успех", "Турнир '" + name + "' успешно создан!");
        } catch (SQLException e) { 
            try { connection.rollback(); } catch (SQLException ignored) {} 
            throw new RuntimeException(e); 
        }
    }
    // Статические классы таблиц
    public static class Player {
        public int playerId; 
        public String fio, playerPosition, phone;
        
        public Player(ResultSet rs) throws SQLException { 
            playerId = rs.getInt("playerId"); 
            fio = rs.getString("fio"); 
            playerPosition = rs.getString("player_position");
            phone = rs.getString("phone"); 
        }
        
        public int getPlayerId() { return playerId; } 
        public String getFio() { return fio; } 
        public String getPlayerPosition() { return playerPosition; }
        public String getPhone() { return phone; }
    }

    public static class Team {
        public int teamId; public String teamName, coach; public int foundedYear;
        public Team(ResultSet rs) throws SQLException { teamId=rs.getInt("teamId"); teamName=rs.getString("teamName"); coach=rs.getString("coach"); foundedYear=rs.getInt("foundedYear"); }
        public int getTeamId() { return teamId; } public String getTeamName() { return teamName; } public String getCoach() { return coach; } public int getFoundedYear() { return foundedYear; }
    }
    
    public static class TeamRoster {
        public int playerId; public String playerName, position; public int jerseyNumber; public String joinedDate;
        public TeamRoster(ResultSet rs) throws SQLException { 
            playerId=rs.getInt("playerId"); 
            playerName=rs.getString("playerName"); 
            position=rs.getString("position"); 
            jerseyNumber=rs.getInt("jerseyNumber"); 
            joinedDate=rs.getString("joinedDate"); 
        }
        public int getPlayerId() { return playerId; } 
        public String getPlayerName() { return playerName; } 
        public String getPosition() { return position; } 
        public int getJerseyNumber() { return jerseyNumber; } 
        public String getJoinedDate() { return joinedDate; }
    }

    public static class Tournament {
        public int tourId; public String tourName, format, status, dates;
        public Tournament(ResultSet rs) throws SQLException { tourId=rs.getInt("tourId"); tourName=rs.getString("tourName"); format=rs.getString("format"); status=rs.getString("status"); dates=rs.getString("dates"); }
        public int getTourId() { return tourId; } public String getTourName() { return tourName; } public String getFormat() { return format; } public String getStatus() { return status; } public String getDates() { return dates; }
    }

    public static class Match {
        public int matchId; public String tourName, matchup, matchDate, score, status;
        public Match(ResultSet rs) throws SQLException { matchId=rs.getInt("matchId"); tourName=rs.getString("tourName"); matchup=rs.getString("matchup"); matchDate=rs.getString("matchDate"); score=rs.getString("score"); status=rs.getString("status"); }
        public int getMatchId() { return matchId; } public String getTourName() { return tourName; } public String getMatchup() { return matchup; } public String getMatchDate() { return matchDate; } public String getScore() { return score; } public String getStatus() { return status; }
    }

    public static class Standing {
        public String teamName; public int played, wins, draws, losses, gf, ga, gd, points;
        public Standing(ResultSet rs) throws SQLException { teamName=rs.getString("team_name"); played=rs.getInt("played"); wins=rs.getInt("wins"); draws=rs.getInt("draws"); losses=rs.getInt("losses"); gf=rs.getInt("gf"); ga=rs.getInt("ga"); gd=rs.getInt("gd"); points=rs.getInt("points"); }
        public String getTeamName() { return teamName; } public int getPlayed() { return played; } public int getWins() { return wins; } public int getDraws() { return draws; } public int getLosses() { return losses; } public int getGf() { return gf; } public int getGa() { return ga; } public int getGd() { return gd; } public int getPoints() { return points; }
    }

    public static void main(String[] args) { launch(args); }
}